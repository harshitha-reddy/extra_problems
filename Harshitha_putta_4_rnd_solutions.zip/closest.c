#include<stdio.h>
int minimumDiff(int *arr,int size)
{

  int diff = arr[1] - arr[0];
  int minelement = arr[0];
  int i;
  for(i = 1; i < size; i++)
  {
     if(arr[i] - minelement < diff)
      diff = arr[i] - minelement;
    if(arr[i] < minelement)
         minelement = arr[i];
  }
  return diff;
}


int main()
{


  int arr[] = {1, 10, 67, 80, 100};
  int i;
  int size = sizeof(arr)/sizeof(arr[0]);
 printf("minimum difference is closest to o is %d",  minimumDiff(arr, size));



  return 0;
}


