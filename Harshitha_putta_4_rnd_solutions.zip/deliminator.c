#include<stdio.h>
#include<stdlib.h>
char * StrDelimiter(char * s, char *delimiter);
void main()
{
	char s[100], *tokens, delimiter[20];
	int i=0;
	printf("Enter the input string \n");
	gets(s);
	printf("Enter the delimiter  \n");
	gets(delimiter);

	tokens = StrDelimiter(s,delimiter);
    printf("The tokens are: \n");
	while(tokens != NULL)
	{
		printf("%s \n", tokens);
		tokens = StrDelimiter(NULL, delimiter);
	}
}
char * StrDelimiter(char * str, char *delimiter)
{
	static int pos;
	static char *rtnStr;
	int i =0;
	int start=pos;
    	int j = 0;


	if(str!=NULL)
		rtnStr = str;
	while(rtnStr[pos] != '\0')
	{
		j = 0;

		while(delimiter[j] != '\0')
		{

			if(rtnStr[pos] == delimiter[j])
			{

				rtnStr[pos] = '\0';
				pos = pos+1;


				if(rtnStr[start] != '\0')
					return (&rtnStr[start]);
				else
				{

					start = pos;

					pos--;
					break;
				}
			}
			j++;
		}
		pos++;
	}
	rtnStr[pos] = '\0';
	if(rtnStr[start] == '\0')
		return NULL;
	else
		return &rtnStr[start];
}
