#include <stdio.h>
#include <stdlib.h>
int xstrlen(char *);
void main()
{

    char str[20];
    int len;
    printf("enter the string");
    gets(str);
    len=xstrlen(str);
    printf("the length is %d",len);
    getch();
}
int xstrlen(char *p)
{
    int l=0;
    while(*p!='\0')
    {

        l++;
        p++;
    }
    return(l);
}



