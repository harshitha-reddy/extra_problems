#include<stdio.h>
void findnum(int *a,int size);
int main()
{
    int a[50],size,i;

    printf("\nEnter the size of the array: ");
    scanf("%d",&size);
    printf("\nEnter %d elements in to the array: ", size);
    for(i=0;i<size;i++)
      scanf("%d",&a[i]);
      findnum(a,size);
      return 0;

      }
      void findnum(int *a,int size)
      {



int   max,i,min;
max=a[0];
  for(i=1;i<size;i++){
      if(max<a[i])
           max=a[i];
  }
  printf("Maximum element: %d\n",max);

  min=a[0];
  for(i=1;i<size;i++){
      if(min>a[i])
           min=a[i];
  }
  printf("minimum element: %d",min);


}


