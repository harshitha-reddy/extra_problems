#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int split(char *str, char *arr[10]){
    int i = 0;
    int j;
    int Words = 10;
    int count = 0;

    while(1){
        while(isspace(str[i])){
            ++i;
        }
        if(str[i] == '\0')
            break;
        j = i;
        while (str[j] && !isspace(str[j])){
            ++j;
        }
        int len = j -i;
        char *tmp = calloc(len + 1, sizeof(char));
        memcpy(tmp, &str[i], len);
        arr[count++] = tmp;
        i= j;
        if (count == Words)
            break;
    }
    return count;
}

int main() {
    char *arr[10];
    int k;
    int n = split("please save trees", arr);

    for(k = 0; k < n; ++k){
        puts(arr[k]);
        free(arr[k]);
    }

    return 0;
}
