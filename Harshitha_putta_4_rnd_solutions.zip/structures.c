#include <stdio.h>
#include <stdlib.h>

struct student
{
    char name[20],department[10],section[10];
    int rollno;

};
void main()
{

    struct student s[3];
    int  i;

    printf("enter the student details");
    for(i=1;i<=3;i++)
        {
    scanf("%s%s%s%d",s[i].name,s[i].department,s[i].section,&s[i].rollno);
    }
    printf("student details are\n");
    for(i=1;i<=3;i++)
    {
    printf("%s \t %s\t %s \t %d\n",s[i].name,s[i].department,s[i].section,s[i].rollno);
        }
getch();
}



