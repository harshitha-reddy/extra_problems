#include <stdio.h>
#include <stdlib.h>
int xstrcmp(char *,char *);
void main()
{
    char str1[20],str2[20];
    int v;
    printf("enter the first string");
    gets(str1);
    printf("enter the second string");
    gets(str2);
    v= xstrcmp(str1,str2);
    if(v==0)
        printf("the strings are equal");
    else
        printf("the strings are not equal");
    getch();
}
int xstrcmp(char *t,char *s)
{
    while(*t!='\0'&&*s!='\0')

    {
        if(*t!=*s)
        return 1;
    t++;
    s++;
    }
    return(0);
}




