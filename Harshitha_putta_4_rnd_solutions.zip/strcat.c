#include <stdio.h>
#include <stdlib.h>
void xstrcat(char *,char *);
void main()
{
    char source[20],target[20];
    printf("enter the sorce string");
    gets(source);
    printf("enter the target string");
    gets(target);
    xstrcat(target,source);
    printf("source string=%s",source);
    printf("target string=%s",target);
    getch();
}
void xstrcat(char *t,char *s)
{
    while(*t!='\0')
    {

        t++;
    }
    while(*s!='\0')
    {
        *t=*s;
        t++;
        s++;

    }
    *t='\0';

}
