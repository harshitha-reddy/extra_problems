
#include <stdio.h>
int main()
{
   char abc[]="hello world this is harshitha";
   int i=0;
   while(abc[i]!='\0')
   {
       if(abc[i]!=' ')
          printf("%c",abc[i]);
       i++;
}
}


