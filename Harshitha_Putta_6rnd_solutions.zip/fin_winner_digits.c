#include<conio.h>
#include<stdio.h>
void Quick_sort( int [10] ,int ,int );
void main()
{
	int a[20],n,i,j=0,count=0,number=a[0];
	printf("Enter any value for n	:");
	scanf("%d",&n);
	printf("entering values into array");
	for(i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
        }
	Quick_sort(a,0,n-1);
	printf("\nThe sorted elements are  :");
		for(i=0;i<n;i++)
        {
        printf("  %d",a[i]);
        }


        for(i=0;i<n;i++)
        {
            if(a[j]==a[i])
            {
                count++;
                number=a[j];

            }

           j=i;
        }
        printf(" the winner number:%d,count:%d",number,count);
	getch();
}
void Quick_sort(int a[20],int lb,int ub)
{
	int pivot,temp,i,j;
	if(lb<ub)
	{
		pivot=lb;
		i=lb;
		j=ub;
		while(i<j)
		{
			while(a[i]<=a[pivot] && i<ub)
			i++;
			while(a[j]>a[pivot])
			j--;

                        if(i<j)
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			else
			break;
		}
		temp=a[pivot];
		a[pivot]=a[j];
		a[j]=temp;
		Quick_sort(a,lb,j-1);
		Quick_sort(a,j+1,ub);
	}
}




