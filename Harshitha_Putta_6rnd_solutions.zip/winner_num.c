#include<stdio.h>
#include<conio.h>
//void winner_digits();
int main()
{
  int i,j,sum,n,a[50],min_sum=0;
  printf("enter the size of array");
  scanf("%d",&n);
  printf("entering the values into array");
   for(i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
   }
  for(i=0;i<n;i++)
  {
      if(i==0)
      {
        sum=a[i]+a[i+1];
        if(min_sum<sum)
        {
            min_sum=sum;

        }
      }

      else if(i!=0&&i+1!=n)
      {
        sum=a[i-1]+a[i]+a[i+1];
         if(min_sum<sum)
         {
            min_sum=sum;
            // printf("%d  ",a[i]);
         }

      }


        else if(i+1==n)
        {
            sum=a[i-1]+a[i];

            if(min_sum<sum)
            {
            min_sum=sum;
            }

        }


  }
  for(i=0;i<n;i++)
    printf("%d",a[i]);
        printf("\n max_sum of winner digit is %d\n",min_sum);


}
