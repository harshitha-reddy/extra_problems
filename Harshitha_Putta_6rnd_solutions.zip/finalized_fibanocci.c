#include<stdio.h>
#include<stdbool.h>
void fibanocci(int );
void main()
{

    int range,k;
 fibanocci(range);
 //binary_search(k);
}
void fibanocci(int range)
{
    int i,u,l,mid,n,c=0,k;
    long int arr[20];
    bool number[10]={false};
    printf("enter the range of numbers:");
    scanf("%d",&range);
    printf("enter a fibanocci number");
    scanf("%d",&n);
    arr[0]=0;
    arr[1]=1;
    for(i=2;i<range;i++)
    {
        arr[i]=arr[i-1]+arr[i-2];
    }

    //k=n-arr[i];
     for(i=0;i<range;i++)
     {
        k=n-arr[i];
       // k=n-arr[i];
      // k=k-arr[i];

     l=0,u=range-1;
    while(l <=u)
         {
         mid=(l+u)/2;
         if(k==arr[mid]){
             c=1;
             break;
         }
         else if(k<arr[mid]){
             u=mid-1;
         }
         else
             l=mid+1;
    }

     if(c==0)
    {
        // printf("The number is not found.");
      number[i]=false;
          // printf("%d ", number[i]);
          //k=k-arr[i];

    }
    else
    {
         printf("The number is  found.\n");
         number[i]=true;
         //number[k]=true;



     }
     }

    for(i=0;i<range;i++)
    {
        printf("%d ",number[i]);
    }
}




