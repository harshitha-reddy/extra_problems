#include<stdio.h>
#include<conio.h>

int bitwisemul(int a,int b)
{
    int c=0;
    while(b!=0)
    {
        if(b&1!=0)
        {
           c=c+a;
        }

        a<<=1;//left shift a by 1
        b>>=1;//right shift b by 1

    }
    return c;
}
int main()
{
    printf("%d",bitwisemul(4,5));
    return 0;

}




