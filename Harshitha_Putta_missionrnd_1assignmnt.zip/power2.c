#include<stdio.h>
#include<conio.h>

/* Function to calculate x raised to the power y modulus z */
int power(unsigned int x, unsigned int y)
{
    if( y == 0)
        return 1;
    else if (y%2 == 0)
        return power(x, y/2)*power(x, y/2);
    else
        return x*power(x, y/2)*power(x, y/2);

}


int main()
{
    int k,s;
    unsigned int x,y,z ;
    printf("enter the values f x any y");
    scanf("%d%d",&x,&y);
    printf("enter the value of z");
    scanf("%d",&z);
    k=power(x,y);
    s=k%z;

    printf("the result is%d",s);
    getch();
}

