#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void printArray(int *product,int n)
{
int i=0;
printf("\noutput\n");
while(i<n)
printf("%d",product[i++]);
}
int productOfAllElements(int *input,int i,int n)
{
int result=1,index=0;
while(index<n)
{
if(index==i)
{
index++;
continue;
}
result*=input[index++];
}
return result;
}
void performFactorial()
{

    int *input,size,index,*resultarray;//this is input;
    printf("size");
    scanf("%d",&size);
    input=(int *)malloc(size*(sizeof(int)));
    resultarray=(int *)malloc(size*(sizeof(int)));
    printf("input:\n");
    for(index=0;index<size;index++)
        scanf("%d",&input[index]);
        index=0;
        while(index<size)
        {
            resultarray[index]=productOfAllElements(input,index,size);
            index++;

        }
        printArray(resultarray,size);
}
void main()
{

performFactorial();
getch();
}


