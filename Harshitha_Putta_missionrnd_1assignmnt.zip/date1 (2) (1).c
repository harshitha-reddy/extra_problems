#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*
* This program is used to print date in english
*/
// This function is used to calculate hundreds in year
void calth(char* a,char* answ,int i)
{
     if(a[i]!='0'){
    if(a[i]=='1')
        strcat(answ,"One");
     else if(a[i]=='2')
        strcat(answ,"Two");
     else if(a[i]=='3')
        strcat(answ,"Three");
     else if(a[i]=='4')
         strcat(answ,"Four");
     else if(a[i]=='5')
        strcat(answ,"Five");
     else if(a[i]=='6')
        strcat(answ,"Six");
     else if(a[i]=='7')
        strcat(answ,"Seven");
     else if(a[i]=='8')
        strcat(answ,"Eight");
     else if(a[i]=='9')
        strcat(answ,"Nine");

     if(i==6)
        strcat(answ," thousand ");
     if(i==7)
        strcat(answ," hundred ");}
}
// this function is used to calculate thousands in year
void calto(char* a,char *answ,int i)
{
    if(a[i]!='0')
    {
       if(a[i]=='1')
       {
           if(a[i+1]=='0')
            strcat(answ,"Ten");
           else if(a[i+1]=='1')
            strcat(answ,"Eleven");
            else if(a[i+1]=='2')
            strcat(answ,"Twelve");
            else if(a[i+1]=='3')
            strcat(answ,"Thirteen");
            else if(a[i+1]=='4')
            strcat(answ,"Fourteen");
            else if(a[i+1]=='5')
            strcat(answ,"Fifteen");
            else if(a[i+1]=='6')
            strcat(answ,"Sixteen");
            else if(a[i+1]=='7')
            strcat(answ,"Seventeen");
            else if(a[i+1]=='8')
            strcat(answ,"Eighteen");
            else if(a[i+1]=='9')
            strcat(answ,"Nineteen");

       }
       else if(a[i]=='2')
       {
       strcat(answ,"Twenty ");
       calth(a,answ,i+1);
       }
       else if(a[i]=='3')
       {
       strcat(answ,"Thirty ");
       calth(a,answ,i+1);
       }
       else if(a[i]=='4')
       {
       strcat(answ,"Forty ");
       calth(a,answ,i+1);
       }
       else if(a[i]=='5')
       {
       strcat(answ,"Fifty ");
       calth(a,answ,i+1);
       }
       else if(a[i]=='6')
       {
       strcat(answ,"Sixty ");
       calth(a,answ,i+1);
       }
       else if(a[i]=='7')
       {
       strcat(answ,"Seventy ");
       calth(a,answ,i+1);
       }
       else if(a[i]=='8')
       {
       strcat(answ,"Eighty ");
       }
       else if(a[i]=='9')
       {
       strcat(answ,"Ninety ");
       calth(a,answ,i+1);
       }

    }
    else{
        calth(a,answ,i+1);
    }

}
// this function is used to calculate month
void calmonth(char *a,char *answ,int i)
{
        if(a[i]=='1')
        {
            if(a[i+1]=='1')
                strcat(answ," November ");
            else if(a[i+1]=='2')
                strcat(answ," December ");
            else if(a[i+1]=='0')
                strcat(answ," October ");

        }
        else if(a[i]=='0')
        {
            if(a[i+1]=='1')
                strcat(answ," January ");
            else if(a[i+1]=='2')
                strcat(answ," February ");
            else if(a[i+1]=='3')
                strcat(answ," March ");
                else if(a[i+1]=='4')
                strcat(answ," April ");
                else if(a[i+1]=='5')
                strcat(answ," May ");
                else if(a[i+1]=='6')
                strcat(answ," June ");
                else if(a[i+1]=='7')
                strcat(answ," July ");
                else if(a[i+1]=='8')
                strcat(answ," August ");
                else if(a[i+1]=='9')
                strcat(answ," September ");
        }



}
// this function is used to calculate date
void caldate(char *a,char *answ,int i)
{
     if(a[i]=='0')
    {

        if(a[i+1]=='1')
            strcat(answ,"First");
        else if(a[i+1]=='2')
            strcat(answ,"Second");
        else if(a[i+1]=='3')
            strcat(answ,"Third");
        else if(a[i+1]=='4')
            strcat(answ,"Fourth");
        else if(a[i+1]=='5')
            strcat(answ,"Fifth");
        else if(a[i+1]=='6')
            strcat(answ,"Sixth");
        else if(a[i+1]=='7')
            strcat(answ,"Seventh");
        else if(a[i+1]=='8')
            strcat(answ,"Eighth");
        else if(a[i+1]=='9')
            strcat(answ,"Ninth");
    }
    else if(a[i]=='1')
    {
        if(a[i+1]=='0')
            strcat(answ,"Tenth");
        else if(a[i+1]=='1')
            strcat(answ,"Eleventh");
        else if(a[i+1]=='2')
            strcat(answ,"Twelfth");
        else if(a[i+1]=='3')
            strcat(answ,"Thirteenth");
        else if(a[i+1]=='4')
            strcat(answ,"Fourteenth");
        else if(a[i+1]=='5')
            strcat(answ,"Fifteenth");
        else if(a[i+1]=='6')
            strcat(answ,"Sixteenth");
        else if(a[i+1]=='7')
            strcat(answ,"Seventeenth");
        else if(a[i+1]=='8')
            strcat(answ,"Eighteenth");
        else if(a[i+1]=='9')
            strcat(answ,"Nineteenth");
                }
    else if(a[i]=='2'){

        strcat(answ,"Twenty ");
         if(a[i+1]=='1')
            strcat(answ,"First");
        else if(a[i+1]=='2')
            strcat(answ,"Second");
        else if(a[i+1]=='3')
            strcat(answ,"Third");
        else if(a[i+1]=='4')
            strcat(answ,"Fourth");
        else if(a[i+1]=='5')
            strcat(answ,"Fifth");
        else if(a[i+1]=='6')
            strcat(answ,"Sixth");
        else if(a[i+1]=='7')
            strcat(answ,"Seventh");
        else if(a[i+1]=='8')
            strcat(answ,"Eighth");
        else if(a[i+1]=='9')
            strcat(answ,"Ninth");

    }
    else if(a[i]=='3')
    {
        if(a[i+1]=='0')
            strcat(answ,"Thirtieth");
        if(a[i+1]=='1')
            strcat(answ,"Thirty first");
    }





}
void main()
{
    char a[10];// a is the array used to store initial input. Name the array as input[10] for better understanding
    char answ[100]=" "; // array used to store output string
    while(1)
    {
    printf("\n\nEnter value in dd/mm/yyyy format or enter \"exit\" to terminate\n");
    scanf("%s",a);
    if(strcmp(a,"exit")==0)// strcmp returns 0 if 2 strings are equal. You can write your own function to compare
        break;
    else
    {
        if(a!=""&&a[2]=='/'&&a[5]=='/')
            {
            caldate(a,answ,0);//for date
            calmonth(a,answ,3);//for month

            calth(a,answ,6);//for year
            calth(a,answ,7);//for year

            calto(a,answ,8);//for year
            }
            else
            {
            printf("Incorrect format");

            }
        printf("\n%s",answ);
        memset(a, 0, sizeof(a));
        memset(answ,0,sizeof(answ));
    }
    }
}
