#include <stdio.h>
#include <string.h>
#include<stdlib.h>
/* Function to swap values at two pointers */
void swap(char *x, char *y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

/* Function to print permutations of string
   This function takes three parameters:
   1. String
   2. Starting index of the string
   3. Ending index of the string. */
void permute(char *a, int l, int r,char *result)
{
   int i;
   if (l == r){
    // printf("%s\n", a);
	 strcat(result,a);
   }
   else
   {
       for (i = l; i <= r; i++)
       {
          swap((a+l), (a+i));
          permute(a, l+1, r,result);
          swap((a+l), (a+i)); //backtrack
       }
   }
}
int converter(char num)
{
	return num-'0';
}
int convertArrayToInteger(char *input,int n)
{
    int result=0;
    int i=0;
    while(i<n)
    {
        result=result*10+converter(input[i++]);
    }
//    printf("%d is retrned ",result);
    return result;
}
void storeResultintoarray(int *result,char *input,int n)
{
    int i=0;
    printf("inside ouput array\n");
    char temparray[n];
    int index=0;
    int index1=0;
    int count=0;
    while(input[i]!='\0')
    {
     if(i!=0&&i%n==0)
     {
 //    printf("\n");
     result[index1++]=convertArrayToInteger(temparray,n);
//	 printf("%d is %d",result[index1-1],count);
     temparray[0]='\0';
     count++;
     index=0;
     }
     temparray[index++]=input[i++];

    }
    result[index1]=convertArrayToInteger(temparray,n);


}
int factorial(int n)
{
    if(n<=1)
        return 1;
    return n*factorial(n-1);
}

void sortResultArray(int result[],int n)
{
    int i,j,size=factorial(n),temp;
    for(i=0;i<size-1;i++)
    {
        for(j=0;j<size-1;j++)
        {
            if(result[i]<result[j])
            {
                temp=result[i];
                result[i]=result[j];
                result[j]=temp;

            }

        }
    }
    printf("Result array is now sorted");

}
/* Driver program to test above functions */
int main()
{
    char str[20];
	char str1[100];
	int result[16]={0};
	int i=0;
	printf("enter a number\n");
	scanf("%s",str);
    int n = strlen(str);
    permute(str, 0, n-1,str1);
//	printf("%s",str1);
	storeResultintoarray(result,str1,n);
	sortResultArray(result,n);
	printf("output : ");
	for(i=0;i<factorial(n);i++)
	    printf("%d ",result[i]);
	printf("\nEnter rank less than %d",factorial(n));
	printf("\n\n%d is result",result[2]);
}

