#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void setOutputarray(int *input,int count,int length)
{
 int i;
 for(i=0;i<count;i++)
	 input[i]=0;
 for(i=count;i<length;i++)
	 input[i]=1;
}
int countOfZeros(int *input,int length)
{
	int i,count=0;
	for(i=0;i<length;i++)
	{
		if(input[i]==0)
			count++;
	}
	return count;
}
void main()
{
	int n,i;int *input,count;
	printf("Enter input length\n");
	scanf("%d",&n);
	input=(int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
	{
		printf("\nenter %d element\n",i+1);
		scanf("%d",&input[i]);
	}
    count=countOfZeros(input,n);
	setOutputarray(input,count,n);
	 for(i=0;i<n;i++)
	 {
		 printf("%d",input[i]);
	 }
		getch();
}