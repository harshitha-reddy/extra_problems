#include<stdio.h>
#include<conio.h>
#include<math.h>
int power(int base,int pow)
{
if(pow==0)
	return 1;
else
	return base*(power(base,pow-1));
}
void convertDecimalToBinary()
{
	int n;
	printf("enter input number\n");
	scanf("%d",&n);
	int n1=n;
	int binarynumber=0;
	int count=0;
	while(n>0)
	{
		
		binarynumber=binarynumber+((n%2)*(power(10,count)));
		n=n/2;
		count++;

	}
	printf("%d",binarynumber);
}
void main()
{
	convertDecimalToBinary();
	getch();
}