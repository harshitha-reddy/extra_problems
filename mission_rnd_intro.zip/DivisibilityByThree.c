#include<stdio.h>
#include<conio.h>
int divisibleByThree(int n)
{

	if(n>0)
	{
		while(n>0)
		n=n-3;
		return n;
	}
	else
	{
		while(n<0)
			n=n+3;
		return n;
	}

}
void checkIfDivisibleByThree()
{
		int n,result;
	printf("enter number\n");
	scanf("%d",&n);
	result=divisibleByThree(n);
	if(!result)
	{
		printf("%d is divisible by 3",n);
	}
	else
	{
		printf("%d is not divisble by 3",n);
	}
}
void main()
{
	checkIfDivisibleByThree();
	getch();
}
