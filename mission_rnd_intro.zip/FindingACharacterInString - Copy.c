#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void searchForCharacter(char *input,char character)
{
	int i=0;
	while(input[i]!='\0')
	{
		if(input[i]==character)
			printf("\n%c character found at %d",character,i);
		i++;
	}
}
void findCharacterInString()
{
	char *input,c;
	int n,i;
	printf("enter size of input string\n");
	scanf("%d",&n);
	input=(char *)malloc((n+1)*(sizeof(char)));
	printf("\nEnter input string of size %d\n",n);
	for(i=0;i<=n;i++)
		scanf("%c",&input[i]);
	input[i]='\0';
	printf("\nPlease enter a character");
	scanf(" %c",&c);
	searchForCharacter(input,c);
}
void main()
{
    findCharacterInString();	
	getch();


}