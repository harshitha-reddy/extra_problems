#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void swap(int *input,int i,int j)
{
	int temp=input[i];
	input[i]=input[j];
	input[j]=temp;
}
void sortTheArray(int *input,int length)
{
	int i,j;
	for(i=0;i<length;i++)
	{
		for(j=0;j<length-1;j++)
		{
			if(input[i]<input[j])
			{
				swap(input,i,j);
			}
		}
	}
}
int KthMax(int *input,int length,int k)
{

	sortTheArray(input,length);
	if(k>length)
		return NULL;
	else
		return input[length-k];



}
void main()
{
	int n;int *input,i,k,result;
	printf(" enter input array length\n");
	scanf("%d",&n);
	input=(int *)malloc(n*(sizeof(int)));
	for(i=0;i<n;i++)
	{
		printf("\nEnter %d element\n",i+1);
		scanf("%d",&input[i]);
	}
	printf("enter k value");
	scanf("%d",&k);
    result=KthMax(input,n,k);
	if(result==NULL)
		printf("\n Wrogn value of k given");
	else
		printf("\n%d max is %d",k,result);
	getch();

}