#include<stdio.h>
#include<conio.h>
void main()
{
    int n,i,j,f;
    printf("enter any number for printing prime numbers till that no\n");
    scanf("%d",&n);
    printf("the prime numbers till %d are\n",n);
    for(i=1;i<=n;i++)
    {
    f=0;
    for(j=1;j<=i;j++)
    {
    if(i%j==0)
    f++;
    }
    if(f==2)
    printf("%d\t",i);
    }
	getch();
}
