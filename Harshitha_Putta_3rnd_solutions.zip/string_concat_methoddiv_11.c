#include<stdio.h>
#include<conio.h>
#include<string.h>

void main()
{
    char p[50],s[30];
    int len,i=0,sum1=0,sum2=0,k=3;
    printf("enter the string1:");
    gets(p);
   // printf("enter the string2:");
    //gets(s);
    strcpy(s,p);





    len=strlen(p);
    if(len%2==0)
    {
        printf("the string is even");
        for(i=0;p[i]!='\0';i+=2)
        {
            sum1=sum1+(p[i]-'0');
        }
        for(i=1;p[i]!='\0';i+=2)
        {
            sum2=sum2+(p[i]-'0');
        }
        diff=sum1-sum2;
        if(diff%11==0)
            printf("the given string is  divisible by 11");
        else
            printf("the given string is not divisible by 11");

    }
    else
    {
        printf("the given string is odd");
        for(i=1;i<k;i++)
        {
            strcat(p,s);
        }


 // p= concat(p, s);
    printf(" Concated string is :%s", p);
   // return p;
   sum=0;
    for(i=0;p[i]!='\0';i+=2)
        {
            sum1=sum1+(p[i]-'0');
        }
        for(i=1;p[i]!='\0';i+=2)
        {
            sum2=sum2+(p[i]-'0');
        }
        diff=sum1-sum2;



    if(diff%11!=0)
        printf("the string is not divisible by 11");
    else
        printf("the string is divisible by 11");
    }



    }


void concat(char  p[], char s[]) {
   int i, j;

   i = strlen(p);

   for (j = 0; s[j] != '\0'; i++, j++) {
      p[i] = s[j];
   }

   p[i] = '\0';
   //return p;
}




