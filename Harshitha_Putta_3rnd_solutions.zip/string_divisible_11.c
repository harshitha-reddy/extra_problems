#include<stdio.h>
#include<conio.h>
#include<string.h>
void divisiblity(char str[100]);
void main()
{
int sum1=0,sum2=0,diff=0,len,i,j;

char str[1000];
printf("enter the string");
gets(str);
len=strlen(str);
divisibility(str);
getch();
}
void divisibility(char str[100])
{

int sum1=0,sum2=0,i,j,diff;
sum1=0;
//for( i=0;i<=len;i=i+2)
for(i=0;str[i]!='\0';i+=2)
{
    sum1=sum1+(str[i]-'0');
}

printf(" the sum 1 is %d",sum1);
sum2=0;

//for( i=1;i<=len;i=i+2)
for(j=1;str[j]!='\0';j+=2)
{
    sum2=sum2+(str[j]-'0');
}
printf("the sum 2 is %d",sum2);
diff=sum1-sum2;
if(diff%11!=0)
{


printf("the string is not divisible by 11");
}
else
{
printf("the string is  divisible by 11");
}
}


