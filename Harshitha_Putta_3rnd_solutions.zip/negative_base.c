#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{

    int a[50],i=0,k,remainder,n;
    printf("accept a decimal value");
    scanf("%d",&n);
    while(n!=0)
    {
        remainder=n%-2;
        n=n/-2;
        if(remainder<0)
        {
          remainder+=2;
          n+=1;
        }
        a[i]=remainder;
        i++;
    }
for(k=i-1;k>=0;k--)
    printf("%d",a[k]);

}
