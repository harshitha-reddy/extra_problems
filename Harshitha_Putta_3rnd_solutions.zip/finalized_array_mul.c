#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<ctype.h>
#include<math.h>
void multiplication(int A[],int B[]);
void main()
{
unsigned int input,input1;
unsigned int *output,*output1;
printf("enter input1 and input2");
scanf("%d%d",&input,&input1);
int index=0,count=1,maxcount,temp,temp1,index1=0,count1=1,maxcount1;
bool true;
bool isfirsttime=true;
unsigned int partofoutput=0,partofoutput2=0;
maxcount=(sizeof(unsigned int)*8);
while(input!=NULL){
if(count<= maxcount)
{
temp=input%2;
input=input/2;
partofoutput+= temp*pow(10,count);
}

}
if(count>maxcount)
{
if(isfirsttime)
{
output = (unsigned int*)malloc((index+1)*(sizeof(unsigned int)));
ouput[index++] =partofoutput;
 bool isfirsttime = false;
}
else {
output  = (unsigned int*) realloc(output,(index+1)*sizeof(unsigned int)); // increase size of output array by 1
ouput[index++] =partofoutput;//A array
count = 0;
}

}

if(count<=maxcount)
{
output1  = (unsigned int*) realloc(output,(index+1)*sizeof(unsigned int));
ouput[index++] =partofoutput;
}
boolean isfirsttime=true;

maxcount1=sizeof(unsigned int)*8;
while(input1!=NULL){
if(count1<= maxcount1)
{
temp1=input1%2;
input1=input1/2;
partofoutput2+= temp1*pow(10,count1);
}

}
if(count1>maxcount)
{
if(isfirsttime)
{
output1 =(unsigned int*)malloc((index1+1)*(sizeof(unsigned int)));
ouput1[index++] =partofoutput2;
 bool isfirsttime = false;
}
else {
output1 = (unsigned int*) realloc(output1,(index1+1)*sizeof(unsigned int));
ouput1[index++] =partofoutput2;//B array
count1 = 0;
}

}

if(count1<=maxcount)
{
output1  = (unsigned int*) realloc(output1,(index1+1)*sizeof(unsigned int));//to increase the size of output array by 1
ouput1[index++] =partofoutput2;


}
 multiplication(output[],output1[]);
}
void multiplication(int output[],int output1[])
{
    unsigned int result=0;
    int index=0,index1=0,maxcount,maxcount1;
    for(index=0;index<=maxcount;index++)
    {
        for(index1=0;index1<=maxcount1;index1++)
        {
            while(output1[index1]!=0)
            {
                if(output1[index]&1)
                {
                    result=result+output[index];
                }
                output[index]<<=1;
                output[index1]>>=1;
            }
        }
    }
    printf("the multiplication of two arrays is %d",result);
    }






