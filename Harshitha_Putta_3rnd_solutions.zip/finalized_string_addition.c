#include <stdio.h>
#include<conio.h>

int getcharval( char *s, int index) {
    if (index < strlen(s))
        return s[strlen(s) - index - 1] - '0';
    return 0;
}

void main() {
     char *a = "1234";
     char *b = "1321";
    char result[256];
    int i, wa=strlen(a), wb=strlen(b), max_len, sum, carry=0;
    max_len = wa > wb ? wa : wb;
    for(i=0; i<max_len; i++){
        char ca = getcharval(a, i);
        char cb = getcharval(b, i);
        printf("%d %d\n", ca, cb);
        sum = ca + cb + carry;
        carry = 0;
        if(sum > 9){
            carry = 1;
            sum-=10;
        }
        result[i] = sum+'0' ;
    }
    if(carry) result[i++] = carry+'0';
    result[i]= 0;
    for (i = 0; i < strlen(result) / 2; i++) {
        char t = result[i];
        result[i] = result[strlen(result) - i - 1];
        result[strlen(result) - i - 1] = t;
    }

    printf("%s\n", result);
}











