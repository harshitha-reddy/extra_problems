// C program to print all permutations with duplicates allowed
#include <stdio.h>
#include <string.h>

void swap(char *x, char *y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
void permute(char *a, int left, int right)
{
   int i;
   if (left == right)
     printf("%s\n", a);
   else
   {
       for (i = left; i <= right; i++)
       {
          swap((a+left), (a+i));
          permute(a, left+1, right);
          swap((a+left),(a+i));
       }
   }
}
int main()
{
    char str[] = "987654321";
    int n = strlen(str);
    permute(str, 0, n-1);
    return 0;
}
