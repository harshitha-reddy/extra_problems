#include<stdio.h>
#include<conio.h>
#include<string.h>

void main() {

   char p[50], s[30];
   int k=3,i,sum=0,a,l,m;

   printf("\nEnter String 1 :");
   gets(p);
   strcpy(s,p);
  // printf("\nEnter String 2 :");
  // gets(s);
   a=strlen(p);
   for(i=1;i<k;i++)
   {
       strcat(p,s);
   }


 // p= concat(p, s);
    printf(" Concated string is :%s", p);
   // return p;
   sum=0;

        for(l=0;p[l]!='\0';l++)
        {
            sum=sum+(p[l]-'0');
        }
        printf("%d",sum);


    if(sum%3!=0)
        printf("the string is not divisible by 3");
    else
        printf("the string is divisible by 3");


    getch();
}

void concat(char  p[], char s[]) {
   int i, j;

   i = strlen(p);

   for (j = 0; s[j] != '\0'; i++, j++) {
      p[i] = s[j];
   }

   p[i] = '\0';
   //return p;
}
